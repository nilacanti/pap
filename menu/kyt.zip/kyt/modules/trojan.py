from kyt import *

#delete
@bot.on(events.CallbackQuery(data=b'delete7-trojan'))
async def delete_trojan(event):
	async def delete_trojan_(event):
		async with bot.conversation(chat) as user:
			await event.respond(f"""
**👉 Input Your UserName :**
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | deltr | sleep 3 | exit'
		subprocess.check_output(cmd, shell=True)
		await event.respond(f"""
**» SUCCES**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#CRATE trojan
@bot.on(events.CallbackQuery(data=b'create7-trojan'))
async def create_trojan(event):
	async def create_trojan_(event):
		async with bot.conversation(chat) as user:
			await event.respond(f"""
**⚠️ No Spasi**
**⚠️ No Double Name**

**👉 Input Your UserName :**
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**» Expired (Hari) :**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**» Limit User (GB) :**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as pw2:
			await event.respond("**» Limit User (IP) :**")
			pw2 = pw2.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw2 = (await pw2).raw_text
		cmd = f'printf "%s\n" "{user}" "{exp}" "{pw}" "{pw2}" | addtr | sleep 3 | exit'
		subprocess.check_output(cmd, shell=True)
		await event.respond(f"""
**» SUCCES CREATE**
**» DONE**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

# TRIAL trojan
@bot.on(events.CallbackQuery(data=b'trial7-trojan'))
async def trial_trojan(event):
	async def trial_trojan_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Expired (Minutes) :**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		cmd = f'printf "%s\n" "{exp}" | trialtr | sleep 3 | exit'
		subprocess.check_output(cmd, shell=True)
		await event.respond(f"""
**» SUCCES CREATE**
**» DONE**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#CEK
@bot.on(events.CallbackQuery(data=b'cek7-trojan'))
async def cek_trojan(event):
	async def cek_trojan_(event):
		cmd = 'bot-cek-tr'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**⚠️ TROJAN USER ONLINE**
{z}
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_trojan_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'trojan'))
async def trojan(event):
	async def trojan_(event):
		inline = [
[Button.inline(" Trial ","trial7-trojan"),
Button.inline(" Create ","create7-trojan")],
[Button.inline(" Login ","cek7-trojan"),
Button.inline(" Delete ","delete7-trojan")],
[Button.inline("‹ Main Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🔥 MENU TROJAN**
━━━━━━━━━━━━━━━━━━━━━━━ 
⚡ **» Service:** `TROJAN`
⚡ **» Hostname/IP:** `{DOMAIN}`
⚡ **» ISP:** `{z["isp"]}`
⚡ **» Country:** `{z["country"]}`
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trojan_(event)
	else:
		await event.answer("Access Denied",alert=True)